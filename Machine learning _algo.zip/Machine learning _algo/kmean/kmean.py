import pandas as pd
import numpy as np

pd_full_data_set = pd.read_csv('Iris.csv')
pd_data_set = pd_full_data_set.copy()
no_of_instances = len(pd_data_set.index)
no_of_columns = len(pd_data_set.columns)
no_of_attributes = no_of_columns - 2
actual_class_column = no_of_columns - 1
unique_class_list_df = pd_data_set.iloc[:, actual_class_column]
unique_class_list_np = unique_class_list_df.unique()
unique_class_list_df = unique_class_list_df.drop_duplicates()
num_unique_classes = len(unique_class_list_df)
K = num_unique_classes
instance_id_colname = pd_data_set.columns[0]
class_column_colname = pd_data_set.columns[actual_class_column]
pd_data_set = pd_data_set.drop(
    columns=[instance_id_colname, class_column_colname])
np_data_set = pd_data_set.to_numpy(copy=True)
centroids = np_data_set[np.random.choice(
    np_data_set.shape[0], size=K, replace=False), :]

cluster_assignments = np.empty(no_of_instances)
centroids_the_same = False
max_iterations = 300

while max_iterations > 0 and not (centroids_the_same):
    for row in range(0, no_of_instances):

        this_instance = np_data_set[row]
        min_distance = float("inf")

        for row_centroid in range(0, K):
            this_centroid = centroids[row_centroid]
            distance = np.linalg.norm(this_instance - this_centroid)
            if distance < min_distance:
                cluster_assignments[row] = row_centroid
                min_distance = distance
    print("Cluster assignments completed for all " +
          str(no_of_instances) + " instances. Here they are:")
    print(cluster_assignments)
    print()
    print("Now calculating the new centroids")
    print()

    print("Cluster assignments completed for all " +
          str(no_of_instances) + " instances. Here they are:" + "\n")
    print(str(cluster_assignments))
    print("\n")
    print("\n")
    print("Now calculating the new centroids" + "\n")
    print("\n")

    old_centroids = centroids.copy()

    for row_centroid in range(0, K):
        for col_centroid in range(0, no_of_attributes):
            running_sum = 0.0
            count = 0.0
            average = None

            for row in range(0, no_of_instances):
                if (row_centroid == cluster_assignments[row]):
                    running_sum += np_data_set[row, col_centroid]
                    count += 1

                    if (count > 0):
                        average = running_sum / count
            centroids[row_centroid, col_centroid] = average
    print("New centroids have been created:")
    print(centroids)
    print()

    print("New centroids have been created:" + "\n")
    print(str(centroids))
    print("\n")
    print("\n")

    centroids_the_same = np.array_equal(old_centroids, centroids)

    max_iterations -= 1
actual_class_col_name = pd_full_data_set.columns[len(
    pd_full_data_set.columns) - 1]
pd_full_data_set = pd_full_data_set.reindex(columns=[*pd_full_data_set.columns.tolist(
), 'Cluster', 'Silhouette Coefficient', 'Predicted Class', ('Prediction Correct?')])

pd_full_data_set['Cluster'] = cluster_assignments

print("Calculating the Silhouette Coefficients" + "\n")
print("\n")
print()
silhouette_column = actual_class_column + 2
for row in range(0, no_of_instances):

    this_instance = np_data_set[row]
    this_cluster = cluster_assignments[row]

    a = None
    running_sum = 0.0
    counter = 0.0
    for row_2 in range(0, no_of_instances):
        if this_cluster == cluster_assignments[row_2]:
            distance = np.linalg.norm(this_instance - np_data_set[row_2])
            running_sum += distance
            counter += 1
    if counter > 0:
        a = running_sum / counter
    b = float("inf")

    for clstr in range(0, K):

        running_sum = 0.0
        counter = 0.0
        if clstr != this_cluster:
            for row_3 in range(0, no_of_instances):

                if cluster_assignments[row_3] == clstr:
                    distance = np.linalg.norm(this_instance - np_data_set[
                        row_3])
                    running_sum += distance
                    counter += 1

            if counter > 0:
                avg_distance_to_cluster = running_sum / counter
            if avg_distance_to_cluster < b:
                b = avg_distance_to_cluster
    s = (b - a) / max(a, b)
    pd_full_data_set.iloc[row, silhouette_column] = s

class_mappings = pd.DataFrame(index=range(K), columns=range(1))

for clstr in range(0, K):

    temp_df = pd_full_data_set.loc[pd_full_data_set['Cluster'] == clstr]

    class_mappings.iloc[clstr, 0] = temp_df.mode()[actual_class_col_name][0]

cluster_column = actual_class_column + 1
pred_class_column = actual_class_column + 3
pred_correct_column = actual_class_column + 4
for row in range(0, no_of_instances):

    for clstr in range(0, K):
        if clstr == pd_full_data_set.iloc[row, cluster_column]:
            pd_full_data_set.iloc[
                row, pred_class_column] = class_mappings.iloc[clstr, 0]

    if pd_full_data_set.iloc[row, pred_class_column] == pd_full_data_set.iloc[
            row, actual_class_column]:
        pd_full_data_set.iloc[row, pred_correct_column] = 1
    else:
        pd_full_data_set.iloc[row, pred_correct_column] = 0
silhouette_coefficient = pd_full_data_set.loc[:,
                                              "Silhouette Coefficient"].mean()

accuracy = (pd_full_data_set.iloc[:,
            pred_correct_column].sum())/no_of_instances

accuracy *= 100
print()
print("Number of Instances : " + str(no_of_instances))
print("Value for k : " + str(K))
print("Silhouette Coefficient : " + str(silhouette_coefficient))
print("Accuracy : " + str(accuracy) + "%")
