import pandas as pd

f = pd.read_csv('finds.csv')
df = f  # Assign the read DataFrame to the variable df

m = len(df.columns) - 1
print(m)

h = ['0'] * m
print(h)

attr = []
for k in df.columns:
    attr.append(k)

print(attr)

target_variable = attr[-1]
print(target_variable)

attr.remove(target_variable)
print(attr)

df_yes = df[df[target_variable] == "yes"]
df_yes

count = 0
for data in attr:
    if (df_yes[data][0] == df_yes[data]).all():
        h[count] = df_yes[data][0]
    else:
        h[count] = "?"
    count += 1

print(h)
