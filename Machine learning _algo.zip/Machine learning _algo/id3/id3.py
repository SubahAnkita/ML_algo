import numpy as np
import pandas as pd
import math
from pprint import pprint


def entropy(target_col):
    elements, counts = np.unique(target_col, return_counts=True)
    entropy = np.sum([(-counts[i]/np.sum(counts))*np.log2(counts[i] /
                     np.sum(counts)) for i in range(len(elements))])
    return entropy


def InfoGain(data, split_attribute_name, target_name="play"):
    total_entropy = entropy(data[target_name])
    vals, counts = np.unique(data[split_attribute_name], return_counts=True)
    Weighted_Entropy = np.sum([(counts[i]/np.sum(counts))*entropy(data.where(
        data[split_attribute_name] == vals[i]).dropna()[target_name]) for i in range(len(vals))])
    Information_Gain = total_entropy - Weighted_Entropy
    return Information_Gain


def id3(data, original_data, features, target_attribute_name='play', parent=None, link=None):
    if len(np.unique(data[target_attribute_name])) <= 1:
        return np.unique(data[target_attribute_name])[0]
    parent_node_class = np.unique(data[target_attribute_name])[np.argmax(
        np.unique(data[target_attribute_name], return_counts=True)[1])]
    item_values = [InfoGain(data, feature, target_attribute_name)
                   for feature in features]
    best_feature_index = np.argmax(item_values)
    best_feature = features[best_feature_index]
    tree = {best_feature: {}}
    features = [i for i in features if i != best_feature]
    for value in np.unique(data[best_feature]):
        if value != 'Outlook':
            sub_data = data.where(data[best_feature] == value).dropna()
            subtree = id3(sub_data, data, features,
                          target_attribute_name, parent_node_class)
            tree[best_feature][value] = subtree
    return tree


d = pd.read_csv('3.csv', names=['outlook', 'temp', 'humidity', 'wind', 'play'])
training_data = d
tree = id3(training_data, training_data, training_data.columns[:-1])
pprint(tree)
