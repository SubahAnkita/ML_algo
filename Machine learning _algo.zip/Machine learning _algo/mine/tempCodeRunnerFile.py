import csv

f =open('Decision Making_lab Excel.csv','r')
reader=csv.reader(f)
for row in reader:
    print(row)
   